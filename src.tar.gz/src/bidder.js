module.exports = (class Bidder {
    /**
     * 
     * @param {String} id 
     * @param {number} bids 
     */
    constructor(id, bid) {
        this.id = id;
        this.bid = bid;
    }
})