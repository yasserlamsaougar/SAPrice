module.exports =  {
    bidders: [
        
    ],
    objectValue: 100
}