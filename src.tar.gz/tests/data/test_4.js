module.exports =  {
    bidders: [
        {
            id: 'A',
            bids: [110, 130]
        },
        {
            id: 'B',
            bids: []
        },
        {
            id: 'C',
            bids: [125]
        },
        {
            id: 'D',
            bids: [105, 115, 90]
        },
        {
            id: 'E',
            bids: [132, 135, 140]
        }
    ],
    objectValue: 100
}