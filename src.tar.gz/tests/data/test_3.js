module.exports =  {
    bidders: [
        {
            id: '0',
            bids: [1, 2, 3]
        },
        {
            id: '1',
            bids: [23, 14, 16]
        },
        {
            id: '2',
            bids: [32, 39, 41]
        },
        {
            id: '3',
            bids: [90, 99, 0]
        }
    ],
    objectValue: 200
}