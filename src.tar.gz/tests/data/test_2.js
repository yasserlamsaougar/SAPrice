module.exports =  {
    bidders: [
        {
            id: '0',
            bids: []
        },
        {
            id: '1',
            bids: []
        },
        {
            id: '2',
            bids: []
        },
        {
            id: '3',
            bids: []
        }
    ],
    objectValue: 100
}