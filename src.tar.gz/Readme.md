# Introduction 

Solution to a second price auction exercice in javascript

# Usage

npm install

# Test

npm test